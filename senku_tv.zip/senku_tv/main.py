import xbmc
import xbmcgui
import xbmcplugin
import sys

# URL del archivo de lista de canales (modifica esta URL con la ubicación de tu lista M3U)
CHANNELS_LIST_URL = "https://github.com/Tbleo1189/Senku-Tv/blob/main/Senkutvfull.m3u"

def get_channels():
    # Leer el archivo M3U de canales acestream desde la URL proporcionada
    import requests
    response = requests.get(CHANNELS_LIST_URL)
    lines = response.text.splitlines()

    channels = []
    current_channel = {}
    for line in lines:
        line = line.strip()
        if line.startswith("#EXTINF:"):
            # Obtener nombre del canal
            current_channel = {'name': line.split(",")[1]}
        elif line.startswith("acestream://"):
            # Añadir el enlace de acestream al canal
            current_channel['url'] = line
            channels.append(current_channel)
            current_channel = {}
    return channels

def list_channels():
    # Listar todos los canales
    channels = get_channels()
    for channel in channels:
        list_item = xbmcgui.ListItem(label=channel['name'])
        url = f"{sys.argv[0]}?url={channel['url']}"
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def play_channel(url):
    # Reproducir el canal acestream
    play_item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=play_item)

def router(paramstring):
    # Manejar la navegación en el addon
    import urllib.parse as urlparse
    params = dict(urlparse.parse_qsl(paramstring))
    if 'url' in params:
        play_channel(params['url'])
    else:
        list_channels()

if __name__ == '__main__':
    router(sys.argv[2][1:])
